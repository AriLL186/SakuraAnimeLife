SAKURA ANIME LIFE - PROYEK ANDROID

Game: simulasi kehidupan anime dengan karakter utama Aoi.
Proyek ini disiapkan untuk build APK otomatis lewat GitHub Actions dari HP.

CARA BUILD APK DARI HP:
1. Buat akun / masuk ke GitHub di https://github.com
2. Buat repository baru bernama SakuraAnimeLife (boleh Public atau Private).
3. Upload semua isi folder proyek ZIP ini ke repository, termasuk folder tersembunyi .github/workflows.
4. Buka tab Actions di repository.
5. Pilih workflow "Build Sakura Anime Life APK", lalu tekan Run workflow (jika workflow belum berjalan otomatis).
6. Tunggu sampai workflow selesai dengan tanda hijau.
7. Buka hasil run, scroll ke Artifacts, unduh SakuraAnimeLife-debug-apk.
8. Ekstrak ZIP hasil artifact, lalu instal app-debug.apk di HP. Jika diminta, izinkan instalasi dari sumber tersebut.

CATATAN:
- Ini APK debug untuk uji coba pribadi, bukan rilis Play Store.
- Build membutuhkan koneksi internet.
- Jika upload melalui aplikasi GitHub sulit, gunakan browser Chrome dengan tampilan Situs desktop.
- Pastikan seluruh folder dan file proyek ikut terunggah, terutama .github/workflows/build-apk.yml.
